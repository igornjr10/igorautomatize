
import React, { useState, useRef, useEffect } from 'react';
import { Workout } from '../types';

interface TrainingModuleProps {
  workouts: Workout[];
  onAddWorkout: (w: Workout) => void;
}

const TrainingModule: React.FC<TrainingModuleProps> = ({ workouts, onAddWorkout }) => {
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isTimerRunning) {
      timerRef.current = window.setInterval(() => {
        setTimer(t => t + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isTimerRunning]);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const [type, setType] = useState<Workout['type']>('STRENGTH');
  const [intensity, setIntensity] = useState<Workout['intensity']>('MEDIUM');

  const handleSave = () => {
    const w: Workout = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      intensity,
      duration: Math.floor(timer / 60) || 1,
      date: new Date().toISOString()
    };
    onAddWorkout(w);
    setTimer(0);
    setIsTimerRunning(false);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="mb-10">
        <h2 className="text-2xl font-outfit font-bold">Treino & Saúde</h2>
        <p className="text-gray-500 text-sm">Monitore sua performance física.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <section className="space-y-8">
          <div className="bg-[#121212] border border-white/5 p-8 rounded-3xl text-center">
             <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-8">Cronômetro de Treino</h3>
             <div className="text-7xl font-outfit font-bold mb-8 tabular-nums tracking-tighter">
               {formatTime(timer)}
             </div>
             <div className="flex gap-4">
                <button 
                  onClick={() => setIsTimerRunning(!isTimerRunning)} 
                  className={`flex-1 py-4 rounded-2xl font-bold transition-all ${isTimerRunning ? 'bg-orange-600 text-white' : 'bg-emerald-600 text-white hover:bg-emerald-500'}`}
                >
                  {isTimerRunning ? 'Pausar' : 'Iniciar Treino'}
                </button>
                <button 
                  onClick={handleSave}
                  disabled={timer === 0}
                  className="flex-1 py-4 bg-white text-black font-bold rounded-2xl disabled:opacity-50"
                >
                  Salvar
                </button>
             </div>
          </div>

          <div className="bg-indigo-600/10 border border-indigo-500/20 p-6 rounded-3xl">
            <h4 className="text-sm font-bold text-indigo-400 uppercase mb-4">Configurações Rápidas</h4>
            <div className="grid grid-cols-2 gap-4">
               <div>
                 <p className="text-[10px] font-bold text-gray-500 mb-2 uppercase">Tipo</p>
                 <select 
                    value={type} 
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full bg-white/5 border-none rounded-xl text-xs py-3"
                 >
                   <option value="STRENGTH">Força</option>
                   <option value="CARDIO">Cardio</option>
                   <option value="FLEXIBILITY">Flexibilidade</option>
                 </select>
               </div>
               <div>
                 <p className="text-[10px] font-bold text-gray-500 mb-2 uppercase">Intensidade</p>
                 <select 
                    value={intensity} 
                    onChange={(e) => setIntensity(e.target.value as any)}
                    className="w-full bg-white/5 border-none rounded-xl text-xs py-3"
                 >
                   <option value="LOW">Leve</option>
                   <option value="MEDIUM">Moderada</option>
                   <option value="HIGH">Intensa</option>
                 </select>
               </div>
            </div>
          </div>
        </section>

        <section className="space-y-6">
           <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Vídeos & Tutoriais</h3>
           <div className="aspect-video bg-[#121212] border border-white/5 rounded-3xl overflow-hidden group relative cursor-pointer">
              <img src="https://picsum.photos/seed/workout/800/450" alt="Tutorial" className="w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity" />
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className="w-16 h-16 bg-white/10 backdrop-blur rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                   <span className="text-white text-2xl">▶</span>
                 </div>
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <p className="text-sm font-bold">Guia de Treino de Força para Iniciantes</p>
                <p className="text-[10px] text-gray-400">YouTube Academy • 12 min</p>
              </div>
           </div>

           <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest pt-4">Histórico</h3>
           <div className="space-y-3">
             {workouts.slice(0, 5).map(w => (
               <div key={w.id} className="bg-white/5 p-4 rounded-xl flex items-center justify-between">
                 <div className="flex items-center gap-3">
                   <div className="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-500 flex items-center justify-center text-xs">💪</div>
                   <div>
                     <p className="text-sm font-bold">{w.type === 'STRENGTH' ? 'Força' : w.type === 'CARDIO' ? 'Cardio' : 'Flex'}</p>
                     <p className="text-[10px] text-gray-500">{new Date(w.date).toLocaleDateString()}</p>
                   </div>
                 </div>
                 <div className="text-right">
                    <p className="text-xs font-bold">{w.duration} min</p>
                    <p className="text-[10px] text-gray-500">{w.intensity}</p>
                 </div>
               </div>
             ))}
             {workouts.length === 0 && <p className="text-gray-600 italic text-sm py-8 text-center">Nenhum treino registrado.</p>}
           </div>
        </section>
      </div>
    </div>
  );
};

export default TrainingModule;
