
import React, { useState } from 'react';
import { Habit, Task, Priority } from '../types';

interface HabitsModuleProps {
  habits: Habit[];
  tasks: Task[];
  toggleHabit: (id: string) => void;
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>;
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

const HabitsModule: React.FC<HabitsModuleProps> = ({ habits, tasks, toggleHabit, setHabits, setTasks }) => {
  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitTime, setNewHabitTime] = useState('');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskTime, setNewTaskTime] = useState('');
  const [showHabitTime, setShowHabitTime] = useState(false);
  const [showTaskTime, setShowTaskTime] = useState(false);

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;
    const colors = ['bg-indigo-500', 'bg-emerald-500', 'bg-orange-500', 'bg-pink-500', 'bg-blue-500'];
    const newHabit: Habit = {
      id: Math.random().toString(36).substr(2, 9),
      name: newHabitName,
      streak: 0,
      completedToday: false,
      color: colors[Math.floor(Math.random() * colors.length)],
      reminderTime: newHabitTime || undefined
    };
    setHabits([...habits, newHabit]);
    setNewHabitName('');
    setNewHabitTime('');
    setShowHabitTime(false);
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTaskTitle,
      completed: false,
      priority: Priority.MEDIUM,
      dueDate: new Date().toISOString(),
      reminderTime: newTaskTime || undefined
    };
    setTasks([...tasks, newTask]);
    setNewTaskTitle('');
    setNewTaskTime('');
    setShowTaskTime(false);
  };

  const deleteTask = (id: string) => setTasks(tasks.filter(t => t.id !== id));
  const toggleTask = (id: string) => setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Habits Section */}
      <section>
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-outfit font-bold">Hábitos Diários</h2>
            <p className="text-gray-500 text-sm">Mantenha sua consistência.</p>
          </div>
        </header>

        <form onSubmit={addHabit} className="mb-6 space-y-3">
          <div className="relative group">
            <input 
              type="text" 
              value={newHabitName}
              onChange={(e) => setNewHabitName(e.target.value)}
              placeholder="+ Adicionar novo hábito"
              className="w-full bg-[#121212] border border-white/5 rounded-2xl pl-5 pr-12 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
            <button 
              type="button"
              onClick={() => setShowHabitTime(!showHabitTime)}
              className={`absolute right-4 top-1/2 -translate-y-1/2 text-lg transition-colors ${showHabitTime || newHabitTime ? 'text-indigo-400' : 'text-gray-600 hover:text-gray-400'}`}
              title="Definir lembrete"
            >
              🔔
            </button>
          </div>
          
          {showHabitTime && (
            <div className="flex items-center gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
              <span className="text-xs font-bold text-gray-500 uppercase">Horário do Lembrete:</span>
              <input 
                type="time" 
                value={newHabitTime}
                onChange={(e) => setNewHabitTime(e.target.value)}
                className="bg-[#1a1a1a] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          )}
        </form>

        <div className="space-y-4">
          {habits.map(habit => (
            <div key={habit.id} className="bg-[#121212] border border-white/5 rounded-2xl p-5 flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => toggleHabit(habit.id)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-white transition-all transform hover:scale-105 active:scale-95 ${habit.completedToday ? 'bg-indigo-600 grayscale-0' : 'bg-gray-800 grayscale opacity-50'}`}
                >
                  {habit.completedToday ? '✓' : '○'}
                </button>
                <div>
                  <h4 className={`font-semibold flex items-center gap-2 ${habit.completedToday ? 'line-through text-gray-600' : 'text-white'}`}>
                    {habit.name}
                    {habit.reminderTime && !habit.completedToday && (
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded border border-indigo-500/20 font-bold">
                        {habit.reminderTime}
                      </span>
                    )}
                  </h4>
                  <p className="text-[10px] uppercase font-bold text-gray-500 mt-1">🔥 {habit.streak} dias de sequência</p>
                </div>
              </div>
              <button 
                onClick={() => setHabits(habits.filter(h => h.id !== habit.id))}
                className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-white/5 rounded-lg text-rose-500"
              >
                ✕
              </button>
            </div>
          ))}
          {habits.length === 0 && <p className="text-gray-600 italic text-center py-10">Crie seu primeiro hábito acima.</p>}
        </div>
      </section>

      {/* Checklist Section */}
      <section>
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-outfit font-bold">Lista de Tarefas</h2>
            <p className="text-gray-500 text-sm">O que temos para hoje?</p>
          </div>
        </header>

        <form onSubmit={addTask} className="mb-6 space-y-3">
          <div className="relative group">
            <input 
              type="text" 
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="+ Nova tarefa..."
              className="w-full bg-[#121212] border border-white/5 rounded-2xl pl-5 pr-12 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
            <button 
              type="button"
              onClick={() => setShowTaskTime(!showTaskTime)}
              className={`absolute right-4 top-1/2 -translate-y-1/2 text-lg transition-colors ${showTaskTime || newTaskTime ? 'text-blue-400' : 'text-gray-600 hover:text-gray-400'}`}
              title="Definir lembrete"
            >
              🔔
            </button>
          </div>

          {showTaskTime && (
            <div className="flex items-center gap-3 animate-in fade-in slide-in-from-top-2 duration-300">
              <span className="text-xs font-bold text-gray-500 uppercase">Horário da Tarefa:</span>
              <input 
                type="time" 
                value={newTaskTime}
                onChange={(e) => setNewTaskTime(e.target.value)}
                className="bg-[#1a1a1a] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          )}
        </form>

        <div className="space-y-2">
          {tasks.map(task => (
            <div key={task.id} className="flex items-center gap-3 bg-white/5 p-4 rounded-xl group">
              <input 
                type="checkbox" 
                checked={task.completed} 
                onChange={() => toggleTask(task.id)}
                className="w-5 h-5 rounded border-white/20 bg-transparent checked:bg-indigo-600"
              />
              <div className="flex-1 flex items-center justify-between">
                <span className={`text-sm ${task.completed ? 'line-through text-gray-600' : 'text-gray-300'}`}>
                  {task.title}
                </span>
                {task.reminderTime && !task.completed && (
                  <span className="text-[9px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/20 font-bold ml-2">
                    {task.reminderTime}
                  </span>
                )}
              </div>
              <button 
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-600 hover:text-white"
              >
                ✕
              </button>
            </div>
          ))}
          {tasks.length === 0 && <p className="text-gray-600 italic text-center py-10">Sem tarefas pendentes.</p>}
        </div>
      </section>
    </div>
  );
};

export default HabitsModule;
