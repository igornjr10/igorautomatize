
import React, { useState, useEffect, useMemo } from 'react';
import { Habit, Transaction, Task, Workout } from '../types';
import { getGeminiInsight } from '../services/gemini';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  habits: Habit[];
  transactions: Transaction[];
  tasks: Task[];
  workouts: Workout[];
  onQuickAction: (tab: any) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ habits, transactions, tasks, workouts, onQuickAction }) => {
  const [insightData, setInsightData] = useState<{text: string, sources: string}>({ text: 'Analisando performance...', sources: '' });
  const [loadingInsight, setLoadingInsight] = useState(true);

  const dailyScore = useMemo(() => {
    const habitScore = habits.length > 0 ? (habits.filter(h => h.completedToday).length / habits.length) * 50 : 0;
    const taskScore = tasks.length > 0 ? (tasks.filter(t => t.completed).length / tasks.length) * 50 : 0;
    return Math.round(habitScore + taskScore);
  }, [habits, tasks]);

  useEffect(() => {
    const fetchInsight = async () => {
      setLoadingInsight(true);
      const fullText = await getGeminiInsight({ habits, transactions, tasks, workouts });
      const [text, sources] = fullText.split("|||");
      setInsightData({ text: text || fullText, sources: sources || "" });
      setLoadingInsight(false);
    };
    fetchInsight();
  }, [habits.length, transactions.length, tasks.length]);

  const totalIncome = transactions.filter(t => t.type === 'INCOME').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'EXPENSE').reduce((acc, curr) => acc + curr.amount, 0);
  const balance = totalIncome - totalExpense;

  const achievements = [
    { title: "Foco Total", desc: "100% hábitos", active: dailyScore >= 100, icon: "🎯" },
    { title: "Investidor", desc: "Saldo > R$1k", active: balance > 1000, icon: "💎" },
    { title: "Atleta", desc: "3+ treinos", active: workouts.length >= 3, icon: "⚡" },
  ];

  const chartData = useMemo(() => {
     return [
       { name: 'Seg', val: 120 }, { name: 'Ter', val: 300 }, { name: 'Qua', val: 200 },
       { name: 'Qui', val: 278 }, { name: 'Sex', val: 189 }, { name: 'Sáb', val: 239 }, { name: 'Hoje', val: dailyScore * 5 },
     ];
  }, [dailyScore]);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-6 duration-700">
      <header className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-4xl font-outfit font-bold tracking-tight">
            Olá, <span className="bg-gradient-to-r from-indigo-400 to-violet-400 bg-clip-text text-transparent">Focado</span>.
          </h2>
          <p className="text-gray-500 text-sm font-medium">Nível 5 • Mestre da Produtividade</p>
        </div>
        <div className="flex items-center gap-3 bg-white/5 p-2 px-4 rounded-2xl border border-white/10 backdrop-blur-sm">
           <div className="text-right">
             <p className="text-[9px] font-bold text-gray-500 uppercase">XP Mensal</p>
             <p className="text-sm font-bold text-indigo-400">2.450 / 5.000</p>
           </div>
           <div className="w-10 h-10 rounded-full border-2 border-white/5 border-t-indigo-500 flex items-center justify-center text-[9px] font-bold">
             49%
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        {/* Score Card - Mais compacto */}
        <div className="lg:col-span-4 bg-gradient-to-br from-indigo-600 to-violet-700 rounded-3xl p-6 flex flex-col items-center justify-center text-center shadow-xl shadow-indigo-600/10">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/60 mb-4">Score do Dia</h3>
          <div className="relative w-32 h-32 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="64" cy="64" r="56" stroke="rgba(255,255,255,0.1)" strokeWidth="6" fill="transparent" />
              <circle 
                cx="64" cy="64" r="56" 
                stroke="white" 
                strokeWidth="8" 
                fill="transparent" 
                strokeDasharray={352}
                strokeDashoffset={352 - (352 * dailyScore) / 100}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-3xl font-outfit font-bold text-white">{dailyScore}</span>
            </div>
          </div>
          <p className="text-[10px] text-white/70 mt-4 font-bold uppercase tracking-tighter">Meta: {dailyScore}/100</p>
        </div>

        {/* Insight Card - Reduzido e com scroll */}
        <div className="lg:col-span-8 p-6 bg-[#121212] border border-white/10 rounded-3xl relative overflow-hidden flex flex-col min-h-[180px]">
          <div className="absolute top-2 right-4 opacity-10">
            <span className="text-5xl">✨</span>
          </div>
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-3 flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></span>
            Insight Rápido
          </h3>
          <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 max-h-24">
            <p className={`text-base leading-snug font-medium ${loadingInsight ? 'animate-pulse text-gray-700' : 'text-gray-200'}`}>
              {loadingInsight ? "Buscando dados em tempo real..." : `"${insightData.text}"`}
            </p>
          </div>
          {insightData.sources && (
            <div className="mt-3 pt-3 border-t border-white/5">
              <p className="text-[9px] text-gray-500 truncate">
                <span className="font-bold text-gray-600 uppercase mr-1">Fontes:</span> {insightData.sources}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Achievements - Menores */}
      <div className="mb-6 grid grid-cols-3 gap-4">
        {achievements.map((ach, i) => (
          <div key={i} className={`p-3 rounded-xl border transition-all ${ach.active ? 'bg-indigo-500/10 border-indigo-500/30' : 'bg-white/5 border-white/5 opacity-50'}`}>
            <div className="flex items-center gap-2">
              <span className="text-lg">{ach.icon}</span>
              <div className="min-w-0">
                <h5 className="text-[10px] font-bold truncate">{ach.title}</h5>
                <p className="text-[8px] text-gray-500 uppercase font-medium truncate">{ach.desc}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mini Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {[
          { label: 'Saldo', value: `R$ ${balance.toFixed(2)}`, icon: '💰' },
          { label: 'Hábitos', value: `${habits.filter(h => h.completedToday).length}/${habits.length}`, icon: '🔥' },
          { label: 'Tarefas', value: `${tasks.filter(t => t.completed).length}`, icon: '📋' }
        ].map((stat, i) => (
          <div key={i} className="bg-[#121212] border border-white/5 rounded-2xl p-4 hover:border-white/10 transition-all flex justify-between items-center">
            <div>
              <h4 className="font-bold text-gray-500 text-[10px] uppercase tracking-wider">{stat.label}</h4>
              <p className="text-xl font-outfit font-bold">{stat.value}</p>
            </div>
            <span className="text-lg opacity-50">{stat.icon}</span>
          </div>
        ))}
      </div>

      <div className="bg-[#121212] border border-white/5 rounded-3xl p-6">
         <h4 className="font-bold text-gray-400 text-[10px] uppercase tracking-wider mb-6">Gráfico de Performance</h4>
         <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} strokeOpacity={0.1} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#444', fontSize: 9, fontWeight: 'bold'}} />
                <Tooltip 
                  cursor={{stroke: '#333'}}
                  contentStyle={{backgroundColor: '#0a0a0a', border: '1px solid #222', borderRadius: '12px'}}
                  itemStyle={{color: '#fff', fontSize: '10px', fontWeight: 'bold'}}
                />
                <Area type="monotone" dataKey="val" stroke="#6366f1" fillOpacity={1} fill="url(#colorVal)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
         </div>
      </div>
    </div>
  );
};

export default Dashboard;
