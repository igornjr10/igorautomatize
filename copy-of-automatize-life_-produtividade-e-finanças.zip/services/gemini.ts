
import { GoogleGenAI, Modality } from "@google/genai";
import { Habit, Transaction, Task, Workout } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiInsight = async (data: {
  habits: Habit[],
  transactions: Transaction[],
  tasks: Task[],
  workouts: Workout[]
}) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        Contexto do Usuário:
        Hábitos: ${JSON.stringify(data.habits)}
        Transações: ${JSON.stringify(data.transactions)}
        Tarefas: ${JSON.stringify(data.tasks)}
        Treinos: ${JSON.stringify(data.workouts)}

        Instrução: Com base nos dados, forneça um insight ULTRA-CURTO (máximo 150 caracteres) e motivador em português. 
        Não use introduções como "Baseado nos seus dados...". Vá direto ao ponto.
      `,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
      }
    });

    const text = response.text || "";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources = chunks ? "|||" + chunks.map((c: any) => c.web?.uri).filter(Boolean).slice(0, 2).join(", ") : "";

    return text + sources;
  } catch (err) {
    console.error("Erro no Insight:", err);
    return "Mantenha o foco na sua evolução diária!";
  }
};

export const generateVisionImage = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `A highly motivational, aesthetic wallpaper for a productivity app. Theme: ${prompt}. High quality, cinematic lighting, futuristic or nature style.` }],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
        }
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (err) {
    console.error("Erro ao gerar imagem:", err);
    return null;
  }
};

export const chatWithGemini = async (message: string, context: any) => {
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: 'Você é o assistente pessoal do Automatize Life. Use Google Search se o usuário perguntar algo sobre notícias, preços ou fatos atuais.',
      tools: [{ googleSearch: {} }]
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};

export function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encodeBase64(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const connectLiveAssistant = (callbacks: any) => {
  return ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
      },
      systemInstruction: 'Você é o assistente de voz do Automatize Life. Rápido, prático e motivador.',
    },
  });
};
