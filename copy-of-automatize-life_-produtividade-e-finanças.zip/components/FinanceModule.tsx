
import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface FinanceModuleProps {
  transactions: Transaction[];
  addTransaction: (t: Omit<Transaction, 'id'>) => void;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#3b82f6', '#8b5cf6', '#ef4444'];

const FinanceModule: React.FC<FinanceModuleProps> = ({ transactions, addTransaction }) => {
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Alimentação');
  const [type, setType] = useState<'INCOME' | 'EXPENSE'>('EXPENSE');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;
    addTransaction({
      amount: parseFloat(amount),
      description,
      category,
      type,
      date: new Date().toISOString()
    });
    setAmount('');
    setDescription('');
  };

  const categories = ['Alimentação', 'Saúde', 'Lazer', 'Moradia', 'Transporte', 'Salário', 'Outros'];

  const categoryData = useMemo(() => {
    const expenses = transactions.filter(t => t.type === 'EXPENSE');
    const totals = expenses.reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});
    return Object.entries(totals).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  const totalIncome = transactions.filter(t => t.type === 'INCOME').reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'EXPENSE').reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="mb-10 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-outfit font-bold">Fluxo Financeiro</h2>
          <p className="text-gray-500 text-sm">Visão inteligente dos seus recursos.</p>
        </div>
        <div className="flex gap-4">
           <div className="text-right">
             <p className="text-[10px] font-bold text-gray-500 uppercase">Economia Mensal</p>
             <p className="text-lg font-bold text-emerald-400">{(totalIncome > 0 ? ((totalIncome - totalExpense) / totalIncome * 100).toFixed(1) : 0)}%</p>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Form Section */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#121212] border border-white/10 p-8 rounded-3xl backdrop-blur-xl">
             <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-6">Nova Transação</h3>
             <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex bg-white/5 p-1 rounded-2xl mb-4 border border-white/5">
                  <button 
                    type="button" 
                    onClick={() => setType('EXPENSE')} 
                    className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all ${type === 'EXPENSE' ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/20' : 'text-gray-500 hover:text-gray-300'}`}
                  >
                    Despesa
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setType('INCOME')} 
                    className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all ${type === 'INCOME' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'text-gray-500 hover:text-gray-300'}`}
                  >
                    Receita
                  </button>
                </div>
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 uppercase ml-2">Valor</label>
                  <input 
                    type="number" step="0.01" value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0,00"
                    className="w-full bg-white/5 border border-white/5 rounded-2xl px-5 py-4 text-xl font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 uppercase ml-2">Descrição</label>
                  <input 
                    type="text" value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Ex: Aluguel, Supermercado..."
                    className="w-full bg-white/5 border border-white/5 rounded-2xl px-5 py-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-600 uppercase ml-2">Categoria</label>
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-white/5 border border-white/5 rounded-2xl px-5 py-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                  >
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <button type="submit" className="w-full py-5 bg-white text-black font-bold rounded-3xl hover:bg-indigo-50 transition-all transform active:scale-95 shadow-xl shadow-white/5 mt-4">
                  Registrar Agora
                </button>
             </form>
          </div>
        </div>

        {/* Chart & History Section */}
        <div className="lg:col-span-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-[#121212] border border-white/10 p-8 rounded-3xl flex flex-col items-center justify-center">
               <h4 className="text-xs font-bold text-gray-500 uppercase mb-6">Gastos por Categoria</h4>
               <div className="w-full h-48">
                 <ResponsiveContainer width="100%" height="100%">
                   <PieChart>
                     <Pie
                       data={categoryData}
                       cx="50%" cy="50%"
                       innerRadius={40}
                       outerRadius={60}
                       paddingAngle={5}
                       dataKey="value"
                     >
                       {categoryData.map((entry, index) => (
                         <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                       ))}
                     </Pie>
                     <Tooltip 
                        contentStyle={{backgroundColor: '#0a0a0a', border: 'none', borderRadius: '12px', fontSize: '10px'}}
                        itemStyle={{color: '#fff'}}
                     />
                   </PieChart>
                 </ResponsiveContainer>
               </div>
               <div className="flex flex-wrap justify-center gap-3 mt-4">
                  {categoryData.map((c, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[i % COLORS.length]}}></div>
                      <span className="text-[9px] font-bold text-gray-400 uppercase">{c.name}</span>
                    </div>
                  ))}
               </div>
            </div>

            <div className="space-y-4">
              <div className="bg-emerald-500/10 p-8 rounded-3xl border border-emerald-500/20 flex flex-col justify-between">
                 <p className="text-[10px] font-bold text-emerald-500 uppercase mb-2 tracking-tighter">Entradas Totais</p>
                 <p className="text-4xl font-outfit font-bold">R$ {totalIncome.toFixed(2)}</p>
              </div>
              <div className="bg-rose-500/10 p-8 rounded-3xl border border-rose-500/20 flex flex-col justify-between">
                 <p className="text-[10px] font-bold text-rose-500 uppercase mb-2 tracking-tighter">Saídas Totais</p>
                 <p className="text-4xl font-outfit font-bold">R$ {totalExpense.toFixed(2)}</p>
              </div>
            </div>
          </div>

          <div className="bg-[#121212] border border-white/10 p-8 rounded-3xl">
            <h3 className="text-xs font-bold text-gray-500 uppercase mb-6 flex justify-between items-center">
              Histórico Detalhado
              <span className="text-[10px] text-gray-600">{transactions.length} registros</span>
            </h3>
            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {transactions.map(t => (
                <div key={t.id} className="flex items-center justify-between p-5 bg-white/5 rounded-2xl group hover:bg-white/10 transition-all border border-transparent hover:border-white/5">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg ${t.type === 'INCOME' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                      {t.type === 'INCOME' ? '↑' : '↓'}
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-gray-100">{t.description}</h5>
                      <p className="text-[10px] text-gray-500 font-bold uppercase mt-0.5">{t.category} • {new Date(t.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <p className={`text-lg font-outfit font-bold ${t.type === 'INCOME' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {t.type === 'INCOME' ? '+' : '-'} R$ {t.amount.toFixed(2)}
                  </p>
                </div>
              ))}
              {transactions.length === 0 && <p className="text-gray-600 italic text-center py-20 text-sm">Organize suas finanças adicionando uma transação.</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinanceModule;
