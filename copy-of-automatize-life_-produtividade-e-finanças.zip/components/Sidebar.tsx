
import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
    { id: 'habits', label: 'Hábitos & Tarefas', icon: '✅' },
    { id: 'finance', label: 'Financeiro', icon: '💰' },
    { id: 'training', label: 'Treino & Saúde', icon: '💪' },
    { id: 'ai', label: 'Assistente IA', icon: '✨' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 bg-[#111] border-r border-white/5 p-6 h-full">
      <div className="flex items-center gap-3 mb-12">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">
          AL
        </div>
        <h1 className="font-outfit text-lg font-bold tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
          Automatize Life
        </h1>
      </div>

      <nav className="space-y-2 flex-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 ${
              activeTab === item.id 
              ? 'bg-indigo-600/10 text-indigo-400 font-semibold' 
              : 'text-gray-400 hover:bg-white/5'
            }`}
          >
            <span className="text-xl opacity-80">{item.icon}</span>
            <span className="text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-white/5">
        <div className="flex items-center gap-3 p-2 bg-white/5 rounded-xl">
          <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400">
            M
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold truncate">Usuário Premium</p>
            <p className="text-[10px] text-gray-500 truncate">v1.0 (Beta)</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
