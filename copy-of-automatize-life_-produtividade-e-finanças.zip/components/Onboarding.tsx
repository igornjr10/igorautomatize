
import React, { useState } from 'react';
import { Habit } from '../types';

interface OnboardingProps {
  onComplete: (habits: Habit[], category: string) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [habits, setHabits] = useState<string[]>(['Beber água', 'Ler 10 páginas', 'Exercitar-se']);
  const [category, setCategory] = useState('Alimentação');

  const handleNext = () => {
    if (step < 2) setStep(step + 1);
    else {
      const initialHabits: Habit[] = habits.map(name => ({
        id: Math.random().toString(36).substr(2, 9),
        name,
        streak: 0,
        completedToday: false,
        color: 'bg-indigo-500'
      }));
      onComplete(initialHabits, category);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-6 text-white font-inter">
      <div className="max-w-md w-full animate-in fade-in zoom-in duration-700">
        <div className="mb-12 text-center">
          <div className="w-16 h-16 bg-indigo-600 rounded-3xl mx-auto mb-6 flex items-center justify-center text-3xl font-bold shadow-2xl shadow-indigo-600/30">
            AL
          </div>
          <h1 className="text-3xl font-outfit font-bold mb-2 tracking-tight">Automatize Life</h1>
          <p className="text-gray-500">Sua jornada para alta performance começa aqui.</p>
        </div>

        {step === 1 ? (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-center">Vamos definir 3 hábitos iniciais</h2>
            <div className="space-y-3">
              {habits.map((h, i) => (
                <input 
                  key={i}
                  type="text"
                  value={h}
                  onChange={(e) => {
                    const newHabits = [...habits];
                    newHabits[i] = e.target.value;
                    setHabits(newHabits);
                  }}
                  className="w-full bg-[#111] border border-white/10 rounded-2xl px-5 py-4 text-sm focus:ring-2 focus:ring-indigo-500"
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-6 text-center">
            <h2 className="text-xl font-bold">Qual sua prioridade financeira?</h2>
            <p className="text-gray-400 text-sm">Isso ajuda a IA a personalizar seus relatórios.</p>
            <div className="grid grid-cols-2 gap-3">
              {['Alimentação', 'Investimentos', 'Lazer', 'Moradia'].map(c => (
                <button 
                  key={c}
                  onClick={() => setCategory(c)}
                  className={`py-4 rounded-2xl border transition-all ${category === c ? 'bg-indigo-600 border-indigo-500 font-bold' : 'bg-white/5 border-white/5 hover:bg-white/10'}`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="mt-12">
          <button 
            onClick={handleNext}
            className="w-full py-5 bg-white text-black font-bold rounded-3xl hover:bg-gray-200 transition-all flex items-center justify-center gap-2"
          >
            {step === 1 ? 'Próximo Passo' : 'Começar Agora'} <span>→</span>
          </button>
          
          <div className="flex justify-center gap-2 mt-8">
            <div className={`h-1.5 w-12 rounded-full transition-all ${step === 1 ? 'bg-indigo-500' : 'bg-white/10'}`}></div>
            <div className={`h-1.5 w-12 rounded-full transition-all ${step === 2 ? 'bg-indigo-500' : 'bg-white/10'}`}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
