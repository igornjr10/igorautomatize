
import React, { useState, useRef, useEffect } from 'react';
import { connectLiveAssistant, decodeBase64, encodeBase64, decodeAudioData } from '../services/gemini';
import { LiveServerMessage } from '@google/genai';

const LiveAssistant: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef(0);
  const streamRef = useRef<MediaStream | null>(null);

  const startSession = async () => {
    setIsConnecting(true);
    setErrorMsg(null);
    try {
      // Verificar suporte a dispositivos de mídia
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Seu navegador não suporta captura de áudio.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true }).catch(err => {
        if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          throw new Error("Microfone não encontrado. Verifique se o dispositivo está conectado.");
        }
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          throw new Error("Permissão para usar o microfone foi negada.");
        }
        throw err;
      });

      streamRef.current = stream;

      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      inputContextRef.current = inputCtx;

      const sessionPromise = connectLiveAssistant({
        onopen: () => {
          const source = inputCtx.createMediaStreamSource(stream);
          const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
          scriptProcessor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
              int16[i] = inputData[i] * 32768;
            }
            const base64 = encodeBase64(new Uint8Array(int16.buffer));
            sessionPromise.then(session => {
              if (session && typeof session.sendRealtimeInput === 'function') {
                session.sendRealtimeInput({ media: { data: base64, mimeType: 'audio/pcm;rate=16000' } });
              }
            }).catch(console.error);
          };
          source.connect(scriptProcessor);
          scriptProcessor.connect(inputCtx.destination);
          setIsActive(true);
          setIsConnecting(false);
        },
        onmessage: async (message: LiveServerMessage) => {
          const audioBase64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audioBase64 && audioContextRef.current) {
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
            const audioBuffer = await decodeAudioData(decodeBase64(audioBase64), audioContextRef.current, 24000, 1);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += audioBuffer.duration;
            sourcesRef.current.add(source);
            source.onended = () => sourcesRef.current.delete(source);
          }
          if (message.serverContent?.interrupted) {
            sourcesRef.current.forEach(s => {
              try { s.stop(); } catch(e) {}
            });
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
          }
        },
        onerror: (e: any) => {
          console.error("Live Error:", e);
          setErrorMsg("Erro na conexão com a IA.");
          stopSession();
        },
        onclose: () => stopSession()
      });

      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      console.error("Start Session Error:", err);
      setErrorMsg(err.message || "Erro inesperado ao iniciar o assistente.");
      setIsConnecting(false);
      stopSession();
    }
  };

  const stopSession = () => {
    setIsActive(false);
    setIsConnecting(false);
    
    if (sessionRef.current) {
      try { sessionRef.current.close?.(); } catch(e) {}
      sessionRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (inputContextRef.current) {
      inputContextRef.current.close().catch(console.error);
      inputContextRef.current = null;
    }

    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
  };

  useEffect(() => {
    if (errorMsg) {
      const timer = setTimeout(() => setErrorMsg(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMsg]);

  return (
    <div className="fixed bottom-24 right-6 md:bottom-8 md:right-8 z-[100]">
      {errorMsg && (
        <div className="absolute bottom-20 right-0 bg-rose-600/90 backdrop-blur-md text-white text-[10px] px-4 py-2 rounded-xl border border-white/20 shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-300">
          {errorMsg}
        </div>
      )}
      <button
        onClick={isActive ? stopSession : startSession}
        disabled={isConnecting}
        className={`relative w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl ${
          isActive 
          ? 'bg-rose-600 scale-110' 
          : 'bg-indigo-600 hover:bg-indigo-500 hover:scale-105'
        } ${isConnecting ? 'animate-pulse' : ''}`}
      >
        {isActive ? (
          <span className="text-2xl text-white">⏹</span>
        ) : (
          <span className="text-2xl text-white">🎙️</span>
        )}
        
        {isActive && (
          <div className="absolute inset-0 rounded-full animate-ping bg-rose-600 opacity-20"></div>
        )}
        
        <div className="absolute -top-12 right-0 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold border border-white/20 whitespace-nowrap text-white">
          {isActive ? 'IA ouvindo...' : (isConnecting ? 'Conectando...' : 'Falar com IA')}
        </div>
      </button>
    </div>
  );
};

export default LiveAssistant;
