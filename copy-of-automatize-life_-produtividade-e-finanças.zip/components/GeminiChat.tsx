
import React, { useState, useRef, useEffect } from 'react';
import { chatWithGemini, generateVisionImage } from '../services/gemini';

interface GeminiChatProps {
  data: any;
}

const GeminiChat: React.FC<GeminiChatProps> = ({ data }) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string; image?: string }[]>([
    { role: 'bot', text: 'Olá! Sou seu assistente inteligente. Quer gerar uma imagem motivacional para seu dia? Digite "/vision" seguido do tema.' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      if (userMsg.toLowerCase().startsWith('/vision')) {
        const prompt = userMsg.replace('/vision', '').trim() || "sucesso e produtividade";
        const imageUrl = await generateVisionImage(prompt);
        if (imageUrl) {
          setMessages(prev => [...prev, { 
            role: 'bot', 
            text: `Aqui está seu quadro de visão para: ${prompt}`, 
            image: imageUrl 
          }]);
        } else {
          setMessages(prev => [...prev, { role: 'bot', text: 'Desculpe, não consegui gerar a imagem agora.' }]);
        }
      } else {
        const response = await chatWithGemini(userMsg, data);
        setMessages(prev => [...prev, { role: 'bot', text: response || 'Desculpe, não consegui processar isso agora.' }]);
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'bot', text: 'Houve um erro na comunicação. Tente novamente.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-16rem)] md:h-[calc(100vh-8rem)] animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-outfit font-bold">Assistente com Busca Real</h2>
          <p className="text-gray-500 text-sm">Respostas baseadas em fatos atuais e IA generativa.</p>
        </div>
        <div className="flex gap-2">
          <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-[10px] font-bold border border-indigo-500/20">SEARCH ON</span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto space-y-4 mb-6 pr-2 custom-scrollbar">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${
              m.role === 'user' 
              ? 'bg-indigo-600 text-white rounded-tr-none' 
              : 'bg-[#121212] text-gray-200 border border-white/5 rounded-tl-none'
            }`}>
              {m.text}
              {m.image && (
                <div className="mt-3 rounded-xl overflow-hidden shadow-2xl">
                  <img src={m.image} alt="Vision Card" className="w-full object-cover" />
                </div>
              )}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-[#121212] p-4 rounded-2xl rounded-tl-none border border-white/5 flex gap-1">
              <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-100"></span>
              <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce delay-200"></span>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form onSubmit={handleSend} className="relative">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Pergunte algo ou use /vision para imagens..."
          className="w-full bg-[#121212] border border-white/10 rounded-2xl pl-6 pr-16 py-5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
        />
        <button 
          type="submit"
          disabled={!input.trim() || isTyping}
          className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center disabled:opacity-50"
        >
          →
        </button>
      </form>
    </div>
  );
};

export default GeminiChat;
